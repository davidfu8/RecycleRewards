package com.example.recyclerewards;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Activity2 extends MainActivity {

    private Button returnHome;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        TextView recycledTextView = (TextView) findViewById(R.id.totalRecycles);
        recycledTextView.setText(((Integer)yang.getTotalRecycles()).toString(), TextView.BufferType.EDITABLE);

        returnHome = (Button) findViewById(R.id.homeButton);
        returnHome.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), MainActivity.class);
                startActivityForResult(myIntent, 0);
            }
        });
    }

    protected void onResume() {
        super.onResume();
        TextView recycledTextView = (TextView) findViewById(R.id.totalRecycles);
        recycledTextView.setText(((Integer)yang.getTotalRecycles()).toString());
    }
}
