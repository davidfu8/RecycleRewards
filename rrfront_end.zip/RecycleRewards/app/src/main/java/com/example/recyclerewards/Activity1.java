package com.example.recyclerewards;

import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class Activity1 extends MainActivity {

    private Button returnHome;
    CheckBox cb1, cb2, cb3, cb4;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        cb1 = (CheckBox) findViewById(R.id.notificationsCheck);
        boolean checked1 = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("cb1", false);
        cb1.setChecked(checked1);

        cb2 = (CheckBox) findViewById(R.id.publicCheck);
        boolean checked2 = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("cb2", false);
        cb2.setChecked(checked2);

        cb3 = (CheckBox) findViewById(R.id.emailCheck);
        boolean checked3 = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("cb3", false);
        cb3.setChecked(checked3);

        cb4 = (CheckBox) findViewById(R.id.facebookCheck);
        boolean checked4 = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("cb4", false);
        cb4.setChecked(checked4);

        returnHome = (Button) findViewById(R.id.saveandquit);
        returnHome.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), MainActivity.class);
                startActivityForResult(myIntent, 0);
            }
        });
    }

    public void onCheckBoxClicked1(View view) {
        boolean checked = ((CheckBox) view).isChecked();
        switch(view.getId()) {
            case R.id.notificationsCheck:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("cb1", checked).commit();
                break;
        }
    }

    public void onCheckBoxClicked2(View view) {
        boolean checked = ((CheckBox) view).isChecked();
        switch(view.getId()) {
            case R.id.publicCheck:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("cb2", checked).commit();
                break;
        }
    }

    public void onCheckBoxClicked3(View view) {
        boolean checked = ((CheckBox) view).isChecked();
        switch(view.getId()) {
            case R.id.emailCheck:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("cb3", checked).commit();
                break;
        }
    }

    public void onCheckBoxClicked4(View view) {
        boolean checked = ((CheckBox) view).isChecked();
        switch(view.getId()) {
            case R.id.facebookCheck:
                PreferenceManager.getDefaultSharedPreferences(this).edit()
                        .putBoolean("cb4", checked).commit();
                break;
        }
    }
}
