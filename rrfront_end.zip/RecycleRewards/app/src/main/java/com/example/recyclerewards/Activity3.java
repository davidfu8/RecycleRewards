package com.example.recyclerewards;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Activity3 extends MainActivity {
    private Button returnHome, bernie, liz, mike, pete;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_social);

        returnHome = (Button) findViewById(R.id.homeButton);
        returnHome.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), MainActivity.class);
                startActivityForResult(myIntent, 0);
            }
        });

        bernie = (Button) findViewById(R.id.bernieButton);
        bernie.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), ActivityBernie.class);
                startActivityForResult(myIntent, 0);
            }
        });

        liz = (Button) findViewById(R.id.lizButton);
        liz.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), ActivityLiz.class);
                startActivityForResult(myIntent, 0);
            }
        });

        mike = (Button) findViewById(R.id.mikeButton);
        mike.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), ActivityMike.class);
                startActivityForResult(myIntent, 0);
            }
        });

        pete = (Button) findViewById(R.id.peteButton);
        pete.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), ActivityPete.class);
                startActivityForResult(myIntent, 0);
            }
        });
    }
}
