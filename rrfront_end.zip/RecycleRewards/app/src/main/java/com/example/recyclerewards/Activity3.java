package com.example.recyclerewards;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Activity3 extends MainActivity {
    private Button returnHome;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_social);

        returnHome = (Button) findViewById(R.id.homeButton);
        returnHome.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                /*Intent myIntent = new Intent(view.getContext(), MainActivity.class);
                startActivityForResult(myIntent, 0);*/
                Intent intent = new Intent("com.google.zxing.client.android.SCAN");
                Intent intentFinal = intent.putExtra("SCAN_MODE", "QR_CODE_MODE");

                startActivityForResult(intent, 0);
            }
        });
    }
}
