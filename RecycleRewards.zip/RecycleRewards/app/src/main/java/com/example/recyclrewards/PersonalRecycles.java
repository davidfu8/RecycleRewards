package com.example.recyclrewards;

import java.util.*;
import android.widget.*;
import android.media.*;
import android.view.*;
import android.os.*;
import android.app.*;
import android.content.*;

public class PersonalRecycles {
    private int totalRecycles;
    private int[] weekRecycles = new int[7];
    private ArrayList<int[]> weeklyRecycles;
    private GregorianCalendar currentTime;

    PersonalRecycles() {
        totalRecycles = 696969;
        currentTime = new GregorianCalendar();
    }

    public int getTotalRecycles() {
        return totalRecycles;
    }

    public int[] getWeekRecycles() {
        return weekRecycles;
    }

    public ArrayList<int[]> getWeeklyRecycles() {
        return weeklyRecycles;
    }

    public void addRecycles() {
        totalRecycles++;
        weekRecycles[currentTime.DAY_OF_WEEK - 1]++;
    }
}
